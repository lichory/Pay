//
//  WXPayTool.h
//  支付
//
//  Created by apple on 15/10/30.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WXPayModel;
@interface WXPayTool : NSObject

+ (void)payWithWXPayModel:(WXPayModel *)payModel;

@end
