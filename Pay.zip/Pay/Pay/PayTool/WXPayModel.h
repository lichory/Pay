//
//  WXPayModel.h
//  支付
//
//  Created by apple on 15/10/30.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

// 支付类型类型
typedef enum{
    WXPayTypeWeiXinPay = 0,
    WXPayTypeAliPay = 1
}WXPayType;

@interface WXPayModel : NSObject
/**
 *  WXPayModel
 *
 *  @param type           支付类型
 *  @param private_key    私密
 *  @param shop_id        商户id
 *  @param shop_no        商户账号
 *  @param order_no       订单号
 *  @param order_price    订单总价格
 *  @param noti_url       回调地址
 *  @param descriptionStr 描述
 *  @param productName    商品名称
 *
 *  @return WXPayModel
 */
+ (WXPayModel *)payModelWithType:(WXPayType)type
                     private_key:(NSString *)private_key
                         shop_id:(NSString *)shop_id
                         shop_no:(NSString *)shop_no
                        order_no:(NSString *)order_no
                     order_price:(NSString *)order_price
                        noti_url:(NSString *)noti_url
                  descriptionStr:(NSString *)descriptionStr
                     productName:(NSString *)productName;

//支付类型
- (WXPayType)type;
- (NSString *)private_key;
- (NSString *)shop_id;
- (NSString *)shop_no;
- (NSString *)order_no;
- (NSString *)order_price;
- (NSString *)noti_url ;
- (NSString *)descriptionStr ;
- (NSString *)productName;
@end
