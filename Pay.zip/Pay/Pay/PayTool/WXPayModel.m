//
//  WXPayModel.m
//  支付
//
//  Created by apple on 15/10/30.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "WXPayModel.h"

@interface WXPayModel()

@property (nonatomic,copy) NSString * shop_id;//商户id
@property (nonatomic,copy) NSString * shop_no;//商户no
@property (nonatomic,copy) NSString * order_no;//订单号
@property (nonatomic,copy) NSString * noti_url;//回调
@property (nonatomic,copy) NSString * order_price;//订单价格
@property (nonatomic,copy) NSString * private_key; //秘钥
@property (nonatomic,copy) NSString * descriptionStr;
@property (nonatomic,copy) NSString * productName;
@property (nonatomic,assign) WXPayType type;

@end


@implementation WXPayModel

- (void)dealloc {
    [_shop_id release];//商户id
    [_shop_no release];//支付宝账户 或者微信账户
    [_order_no release];//订单号
    [_noti_url release];//回调
    [_order_price release];//订单价格
    [_private_key release]; //秘钥
    [_descriptionStr release];
    [_productName release];
    [super dealloc];
}

+ (WXPayModel *)payModelWithType:(WXPayType)type
                     private_key:(NSString *)private_key
                         shop_id:(NSString *)shop_id
                         shop_no:(NSString *)shop_no
                        order_no:(NSString *)order_no
                     order_price:(NSString *)order_price
                        noti_url:(NSString *)noti_url
                  descriptionStr:(NSString *)descriptionStr
                    productName:(NSString *)productName{
    WXPayModel * payModel = [[[WXPayModel alloc]init]autorelease];
    
    payModel.type = type;
    payModel.private_key = [WXPayModel getSafeStr:private_key];
    payModel.shop_id = [WXPayModel getSafeStr:shop_id];
    payModel.shop_no = [WXPayModel getSafeStr:shop_no];
    payModel.order_no = [WXPayModel getSafeStr:order_no];
    payModel.order_price = [WXPayModel getSafeStr:order_price];
    payModel.noti_url = [WXPayModel getSafeStr:noti_url];
    payModel.descriptionStr = [WXPayModel getSafeStr:descriptionStr];
    payModel.productName = [WXPayModel getSafeStr:productName];
    return payModel;
    
}

- (WXPayType)type {
    return _type;
}
- (NSString *)private_key {
    return _private_key;
}
- (NSString *)shop_id {
    return _shop_id;
}
- (NSString *)order_no {
    return _order_no;
}
- (NSString *)order_price {
    return _order_price;
}
- (NSString *)noti_url {
    return _noti_url;
}
- (NSString *)descriptionStr {
    return _descriptionStr;
}
- (NSString *)productName {
    return _productName;
}

+ (NSString*)getSafeStr:(NSString *)str {
    if (str == nil) {
        return @"";
    }else {
        return str;
    }
}

@end







