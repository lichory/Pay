//
//  WXPayTool.m
//  支付
//
//  Created by apple on 15/10/30.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "WXPayTool.h"
#import "WXPayModel.h"
#import "WXApiObject.h"
#import "WXApi.h"
#import "payRequsestHandler.h"
#import <AlipaySDK/AlipaySDK.h>
#import "Order.h"
#import "DataSigner.h"
#import "PartnerConfig.h"

@implementation WXPayTool

+ (void)payWithWXPayModel:(WXPayModel *)payModel {
    
    if (payModel.type == WXPayTypeWeiXinPay) { // 微信支付
        [WXPayTool weixinPayWithPayModel:payModel];
    }else if(payModel.type == WXPayTypeAliPay) {// 支付宝支付
        [WXPayTool aliPayWithPayModel:payModel];
    }
}

// 支付宝支付
+ (void)aliPayWithPayModel:(WXPayModel *)payModel {
    /*
     *点击获取prodcut实例并初始化订单信息
     */
    Order *order = [[Order alloc] init];
    order.partner = payModel.shop_id;
    order.seller = payModel.shop_no;
    //order.tradeNO = [self generateTradeNO]; //订单ID（由商家自行制定）
    order.tradeNO = payModel.order_no;
    //order.productName = @"充值"; //商品标题
    order.productName = payModel.productName;
    //order.productDescription = [NSString stringWithFormat:@"转入%@",textFiled.text]; //商品描述
    order.productDescription = payModel.descriptionStr;
    order.amount =payModel.order_price;
    order.notifyURL = payModel.noti_url; //回调URL
    order.showUrl = @"m.alipay.com";
    order.inputCharset = @"utf-8";
    order.service = @"mobile.securitypay.pay";
    order.paymentType = @"1"; // 商品购买
    NSString* orderInfo = [order description];
    
    //签名
    id<DataSigner> signer;
    signer = CreateRSADataSigner(payModel.private_key);
    NSString *signedString = [signer signString:orderInfo];
    NSString *orderString = [NSString stringWithFormat:@"%@&sign=\"%@\"&sign_type=\"%@\"",
                             orderInfo, signedString, @"RSA"];
    //支付
    NSString * appScheme = @"WEIXUESchemeUrl";
    [[AlipaySDK defaultService] payOrder:orderString fromScheme:appScheme callback:^(NSDictionary *resultDic) {
        // 这里是
        NSLog(@"resultDic = %@",resultDic);
    }];
}
//微信支付
+ (void)weixinPayWithPayModel:(WXPayModel *)payModel {
    //创建支付签名对象
    payRequsestHandler *req = [payRequsestHandler alloc] ;
    //初始化支付签名对象
    [req init:APP_ID mch_id:payModel.shop_id];
    //设置密钥
    [req setKey:payModel.private_key];
    //获取到实际调起微信支付的参数后，在app端调起支付
    NSMutableDictionary *dict = [req sendPayWithPayModel:payModel];
    if(dict == nil){
        //错误提示
        NSLog(@"error = %@\n\n",[req getDebugifo]);
    }else{
        
        NSMutableString *stamp  = [dict objectForKey:@"timestamp"];
        //调起微信支付
        PayReq* req             = [[PayReq alloc] init];
        req.openID              = [dict objectForKey:@"appid"];
        req.partnerId           = [dict objectForKey:@"partnerid"];
        req.prepayId            = [dict objectForKey:@"prepayid"];
        req.nonceStr            = [dict objectForKey:@"noncestr"];
        req.timeStamp           = stamp.intValue;
        req.package             = [dict objectForKey:@"package"];
        req.sign                = [dict objectForKey:@"sign"];
        [WXApi sendReq:req];
    }
    

}


@end









