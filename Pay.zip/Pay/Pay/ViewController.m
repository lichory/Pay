//
//  ViewController.m
//  Pay
//
//  Created by apple on 15/11/2.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "ViewController.h"
#import "WXPayTool.h"
#import "WXPayModel.h"
#import "PartnerConfig.h"
#import "WXApi.h"
#import "payRequsestHandler.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)alipay:(id)sender {
    
    NSDate * date = [NSDate date];
    NSDateFormatter * dateFormate = [[[NSDateFormatter alloc]init]autorelease];
    dateFormate.dateFormat = @"yyyyMMddHHmmss";
    NSString * dateStr = [dateFormate stringFromDate:date];
    NSString * order_no = dateStr;
    WXPayModel * payModel = [WXPayModel payModelWithType:WXPayTypeAliPay private_key:PartnerPrivKeyHaoNiu shop_id:PartnerIDHaoNiu shop_no:SellerIDHaoNiu order_no:order_no order_price:@"0.01" noti_url:@"http://www.xxx.com" descriptionStr:@"测试" productName:@"商品测试"];
    [WXPayTool payWithWXPayModel:payModel];
    
}
- (IBAction)weixin:(id)sender {
    
    BOOL isRegisterApp = [WXApi registerApp:APP_ID withDescription:@"weiXinPay"];
    if (isRegisterApp) {
        NSDate * date = [NSDate date];
        NSDateFormatter * dateFormate = [[[NSDateFormatter alloc]init]autorelease];
        dateFormate.dateFormat = @"yyyyMMddHHmmss";
        NSString * dateStr = [dateFormate stringFromDate:date];
        NSString * order_no = dateStr;
        WXPayModel * payModel = [WXPayModel payModelWithType:WXPayTypeWeiXinPay private_key:PARTNER_ID shop_id:MCH_ID shop_no:nil order_no:order_no order_price:@"0.01" noti_url:@"http://www.xxx.com" descriptionStr:@"测试" productName:@"商品名字"];
        [WXPayTool payWithWXPayModel:payModel];
        
    }
   
    
}

@end
